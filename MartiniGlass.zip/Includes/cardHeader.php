<meta charset="UTF-8">
		<title>Index</title>
		<link rel="stylesheet" type="text/css" href="./Css/cardDetailsStyle.css">
		<script src=".\Scripts\cardDetails1.js"></script>
		<script src=".\Scripts\CheckOut2.js"></script>