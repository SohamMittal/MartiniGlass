
	<span>Follow Us on:</span>
	
	<a href="https://www.instagram.com/soham3000/"><img class="footericon" src="./Icons/1.png" /></a>
	<a href="https://twitter.com/?lang=en"><img class="footericon" src="./Icons/2.png" /></a>
	<a href="https://www.facebook.com/soham3000"><img class="footericon" src="./Icons/3.png" /></a>
	
