<div id ="headDiv">
				<p class ="tab left"><a href="index.php">
					<img class="icon" src="./Icons/goBack.png" /><span>Back</span>
				</a></p>
				
				<h1>Martini Glass</h1>
				
				
				<p class ="tab right"><a href="checkOut.php">
					<img class="icon" src="./Icons/checkout.png" /><span>Checkout</span>
				</a></p>
				
				
				
				
			</div>