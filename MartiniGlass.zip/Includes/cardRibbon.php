<div id="header">
					<div id ="headDiv">
						<p class ="tab left"><a href="./checkOut.php">
							<img class="icon" src="./Icons/goBack.png" /><span>Back</span>
						</a></p>	
						
						<h1>Martini Glass</h1>
						
						
						
					</div>
					
				</div>	
				<div id="headerRibbon">
					<p><img class="icon2"src="./Icons/lock.png"> Checkout</p>
					
				</div>