<div id="headerRibbon">
			<ul name = "glass_page" >
				<li value = "1" id="selected">High ball</li>
				<li value = "2" >Collins</li>
				<li value = "3" >Old Fashioned</li>
				<li value = "4" >Wine Glasses</li>
				<li value = "5" >Champagne Glasses</li>
				<li value = "6" >Martini Glasses</li>
				<li value = "7" >Beer Mugs</li>
				<li value = "8" >Juice Glasses</li>
				<li value = "9" >Brandy Balloon</li>
				<li value = "10" >Cocktail Glasses</li>
			</ul>
			
		</div>