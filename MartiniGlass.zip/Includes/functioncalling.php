<?php
	
	echo "looools";
	
	
?>