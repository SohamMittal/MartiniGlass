<head>
		<meta charset="UTF-8">
		<title>Matini-Glass</title>
		<link rel="stylesheet" type="text/css" href="./Css/indexStyle.css">
		<script src=".\Scripts\script1.js"></script>
		<script src=".\Scripts\script2.js"></script>
		<script src=".\Scripts\script3.js"></script>
		<script src=".\Scripts\script4.js"></script>
		<script src=".\Scripts\search.js"></script>
		
	</head>