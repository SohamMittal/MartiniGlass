<head>
	<meta charset="UTF-8">
	<title>Index</title>
	<link rel="stylesheet" type="text/css" href="./Css/cartStyle.css">
	<script src=".\Scripts\cart1.js"></script>
	<script src=".\Scripts\cart2.js"></script>
	<script src=".\Scripts\cart3.js"></script>
	
</head>