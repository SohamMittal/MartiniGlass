
		
		<div id="AddedMessage" class="invisibleMessage" ><img src ="./Icons/close.png"><p></p><p id="sideMessage">Closing in</p></div>
		