<meta charset="UTF-8">
		<title>Index</title>
		<link rel="stylesheet" type="text/css" href="./Css/checkoutStyle.css">
		<script src=".\Scripts\CheckOut1.js"></script>
		<script src=".\Scripts\CheckOut2.js"></script>