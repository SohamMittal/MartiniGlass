<table>
	<tr>
		<th colspan="5">Product Name</th>
		<th colspan="5">Price</th>
		<th colspan="5">Quantity</th>
		<th colspan="3">Amount</th>
		<th class="no" colspan="1"></th>
		<th class="no" colspan="1"></th>
	</tr>
	
	<tr>
		<td colspan="10" class="foot no"></td>
		<td colspan="5" class="foot top">Subtotal</td>
		<td colspan="3" id="subtotal" class="foot top"></td>
	</tr>
	<tr>
		<td colspan="10" class="foot no"></td>
		<td colspan="5" class="foot ">GST (5%)</td>
		<td colspan="3" id="Gst"class="foot "></td>
	</tr>
	<tr>
		<td colspan="10" class="foot no"></td>
		<td colspan="5" class="foot ">QGST (9.975%)</td>
		<td colspan="3" id="Qgst"class="foot "></td>
	</tr>
	<tr>
		<td colspan="10" class="foot no"></td>
		<td colspan="5" class="foot top1">Total</td>
		<td colspan="3" id="total"class="foot top1"></td>
	</tr>
</table>